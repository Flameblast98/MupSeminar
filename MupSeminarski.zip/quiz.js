let pos = 0, test, test_status, question, choice, choices, chA, chB, chC, correct = 0;
let questions = [
  {
      question: "Koliko je Freddiju trebalo vremena za napisati jednu od najpoznatijih pjesama Queena, Crazy little thing called love?",
      a: "4 sata",
      b: "2 dana",
      c: "10 minuta",
      answer: "C"
    },
  {
      question: "Kako se zvala Freddijeva najdraža mačka?",
      a: "Miko",
      b: "Delilah",
      c: "Lily",
      answer: "B"
    },
  {
      question: "Koje godine je bila posljednja Freddijeva turneja s Queenom?",
      a: "1986.",
      b: "1984.",
      c: "1987.",
      answer: "A"
    },
  {
      question: "Koje je bilo Freddijevo omiljeno piće?",
      a: "Pivo",
      b: "Vodka",
      c: "Gin",
      answer: "B"
    },
    {
      question: "Za koju pjesmu je sniman spot na proslavi freddijevog rođendana?",
      a: "Stone called crazy",
      b: "Living on my own",
      c: "Friends will be friends",
      answer: "B"
    }
];

function get(x){
  return document.getElementById(x);
}

function renderQuestion(){
  test = get("test");
  if(pos >= questions.length){
    test.innerHTML = "<h2>Postigli ste "+correct+" od "+questions.length+" to&#269;nih odgovora!</h2>";
    get("test_status").innerHTML = "Test je gotov!";
 
    pos = 0;
    correct = 0;

    return false;
  }
  get("test_status").innerHTML = "Pitanje "+(pos+1)+" od "+questions.length;
  
  question = questions[pos].question;
  chA = questions[pos].a;
  chB = questions[pos].b;
  chC = questions[pos].c;
  
  test.innerHTML = "<h3>"+question+"</h3>";

  test.innerHTML += "<label> <input type='radio' name='choices' value='A'> "+chA+"</label><br>";
  test.innerHTML += "<label> <input type='radio' name='choices' value='B'> "+chB+"</label><br>";
  test.innerHTML += "<label> <input type='radio' name='choices' value='C'> "+chC+"</label><br><br>";
  test.innerHTML += "<button onclick='checkAnswer()'>Pohrani odgovor</button>";
}
function checkAnswer(){

  choices = document.getElementsByName("choices");
  for(let i=0; i<choices.length; i++){
    if(choices[i].checked){
      choice = choices[i].value;
    }
  }
  
  if(choice == questions[pos].answer){

    correct++;
  }
 
  pos++;

  renderQuestion();
}

window.addEventListener("load", renderQuestion);